import { Typography, Stack } from '@mui/material';
import Interview from './Interview';

export default async function Page() {
  return <Interview />;
}
