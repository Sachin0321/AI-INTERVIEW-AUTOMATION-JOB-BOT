import JobForm from './job-form';

export default function Page() {
  return <JobForm />;
}
