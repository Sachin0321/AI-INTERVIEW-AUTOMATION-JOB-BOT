import QuestionForm from './QuestionForm';

export default function Page() {
  return <QuestionForm />;
}
